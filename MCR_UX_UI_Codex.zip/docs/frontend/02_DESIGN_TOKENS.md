# Tokens y tipografía

**MCR · Sistema de asistencia | Directrices de implementación | 18-11-2026**

## Integración
`apps/web/src/styles.css` usa Tailwind 4 `@theme inline` y variables semánticas. Evolucionar esa interfaz; no duplicar sistemas. Ejemplo inicial, ajustar contraste tras pruebas:

```css
:root {
  --mcr-black: #000000;
  --mcr-yellow: #FADB25;
  --mcr-white: #FFFFFF;
  --mcr-earth: #2B261A;
  --mcr-blue: #1275B5;
  --mcr-green: #67CF55;
  --mcr-red: #B81111;
  --background: #F6F7F8;
  --foreground: #171717;
  --card: #FFFFFF;
  --primary: var(--mcr-yellow);
  --primary-foreground: var(--mcr-black);
  --secondary: #EFEFF1;
  --muted-foreground: #52525B;
  --border: #D4D4D8;
  --ring: #1275B5;
  --success-text: #236B29;
  --warning-text: #805600;
  --info-text: #125C91;
  --danger-text: #B81111;
  --surface-solid: #FFFFFF;
  --duration-fast: 150ms;
  --duration-normal: 220ms;
}
[data-theme='dark'] {
  color-scheme: dark;
  --background: #101010;
  --foreground: #FAFAFA;
  --card: #1B1B1B;
  --secondary: #272727;
  --muted-foreground: #B5B5BE;
  --border: #505050;
  --ring: #FADB25;
  --success-text: #67CF55;
  --warning-text: #FADB25;
  --info-text: #8CC9F1;
  --danger-text: #FF9999;
  --surface-solid: #1B1B1B;
}
@theme inline {
  --font-sans: 'Google Sans', ui-sans-serif, system-ui, sans-serif;
  --color-primary: var(--primary);
  --color-primary-foreground: var(--primary-foreground);
  --color-ring: var(--ring);
  --color-destructive: var(--danger-text);
}
```
Conservar mappings existentes de card, foreground, accent, input y muted. Unificar tema con variante dark de Tailwind si se utiliza; no mezclar selectores incompatibles. Los colores complementarios son propuestas, no ampliación de marca oficial. Amarillo y verde brillante no como texto sobre blanco; variantes semánticas deben contrastar.

## Fuente oficial
URL suministrada: https://fonts.googleapis.com/css2?family=Google+Sans:ital,opsz,wght@0,17..18,400..700;1,17..18,400..700
Verificar licencia y disponibilidad antes de copiar archivos de fuente; preferir WOFF2 local autorizado con `font-display: swap`. Si se usa URL externa, revisar CSP, privacidad y rendimiento; sin bloquear render por la fuente. Pesos 400/500/600/700; itálica solo cuando procede. No inventar archivos de fuente. Medir CLS por fallback.

## Aceptación
Sin hex de marca dispersos en features; colores de negocio se resuelven mediante variantes semánticas. Probar contrastes AA, foco, disabled y colores en modo alto contraste. No todos los bordes decorativos requieren 3:1, pero los límites funcionales necesarios sí.
